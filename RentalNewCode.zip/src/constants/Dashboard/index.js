const column=[
    { id: "col1", label: "SLNO.", minWidth: 70, align: "center" },
    { id: "col2", label: "ContractType", minWidth: 70, align: "center" },
    { id: "col3", label: "Status", minWidth: 70, align: "center" },
    { id: "col4", label: "Type", minWidth: 70, align: "center" },
]

export {column}