import { Box, Button, Grid, Typography } from "@mui/material";
import React, { useState } from "react";
import InputBoxComponent from "../../../atoms/InputBoxComponent";
import DropDownComponent from "../../../atoms/DropDownComponent";

// const lesseeInformation = {
//   branchid:"",
//   branchName: "",
//   areaName: "",
//   regionName: "",
//   zone: "",
//   state: "",
//   branchType: "",
//   approverRenewal: "",
//   approverRelocation: "",
//   enitityDetails: "",
// };
const LesseeInformation = ({
  activeStep,
  setActiveStep,
  onSave,
  type,
  allNewContractDetails,
  setAllNewContractDetails,
  allNewContractDetailsErr,
  handleAddRentContractInformationError,
}) => {
  // const [lesseeInfo, setLesseeInfo] = useState(lesseeInformation);

  // const NewRentContractLesseeDetails = async () => {
  //   // if (props.type === "add") {
  //   let payload = {
  //     branchId:lesseeInfo?.branchID,
  //     branchName: lesseeInfo?.lesseeBranchName,
  //     areaName: lesseeInfo?.lesseeAreaName,
  //     regionName: lesseeInfo?.lesseeDivision,
  //     zone: lesseeInfo?.lesseeZone,
  //     state: lesseeInfo?.lesseeState,
  //     branchType: lesseeInfo?.lesseeBranchType,
  //     approverRenewal: lesseeInfo?.lesseeApproverrenewals,
  //     approverRelocation: lesseeInfo?.lesseeApproverRelocation,
  //     enitityDetails: lesseeInfo?.lesseeEntityDetails,
  //   };
  //   const { data } = await AddRentContractDetails(payload);
  //   if (data?.data) {
  //     setLesseeInfo({
  //       branchId:"",
  //       branchName: "",
  //       areaName: "",
  //       regionName: "",
  //       zone: "",
  //       state: "",
  //       branchType: "",
  //       approverRenewal: "",
  //       approverRelocation: "",
  //       enitityDetails: "",
  //     });
  //   }
  // };
  const handleNext = () => {
    // let err = handleAddRentContractInformationError();
    // if (err) {
    onSave(allNewContractDetails, type);

    // }
    // setActiveStep((prevActiveStep) => prevActiveStep + 1);
  };

  const handleBack = () => {
    setActiveStep((prevActiveStep) => prevActiveStep - 1);
  };

  const updateChange = (e) => {
    setAllNewContractDetails({
      ...allNewContractDetails,
      [e.target.name]: e.target.value,
    });
  };

  const handleBranchType = (name, value) => {
    setAllNewContractDetails(() => ({
      ...allNewContractDetails,
      [name]: value,
    }));
  };

  const handleApproverRelocate = (name, value) => {
    setAllNewContractDetails(() => ({
      ...allNewContractDetails,
      [name]: value,
    }));
  };

  const handleApproverRenew = (name, value) => {
    setAllNewContractDetails(() => ({
      ...allNewContractDetails,
      [name]: value,
    }));
  };

  const handleEntityDetails = (name, value) => {
    setAllNewContractDetails(() => ({
      ...allNewContractDetails,
      [name]: value,
    }));
  };

  let BranchType = [
    { id: "GL", label: "GL" },
    { id: "RF", label: "RF" },
    { id: "DO/RPC", label: "DO/RPC" },
    {
      id: "Office",
      label: "Office",
    },
    {
      id: "Hostel",
      label: "Hostel",
    },
    { id: "Storage Facility", label: "Storage Facility" },
    { id: "Training", label: "Training" },
  ];

  let ApproverRenew = [
    { id: "DM", label: "DM" },
    { id: "ZM", label: "ZM" },
  ];

  let ApproverRelocate = [
    { id: "SH", label: "SH" },
    { id: "CBO", label: "CBO" },
    { id: "MD/CEO", label: "MD/CEO" },
  ];

  let EntityDetails = [
    { id: "Commercial", label: "Commercial" },
    { id: "Residential", label: "Residential" },
    {
      id: "Both Commercial & Residential",
      label: "Both Commercial & Residential",
    },
  ];

  const handleBulidingType = (name, value) => {
    setAllNewContractDetails(() => ({
      ...allNewContractDetails,
      [name]: value,
    }));
  };

  const handleLocationChange = (name, value) => {
    setAllNewContractDetails(() => ({
      ...allNewContractDetails,
      [name]: value,
    }));
  };

  let location = [
    { id: "Urban", label: "Urban" },
    { id: "Rural", label: "Rural" },
  ];

  let typeOfBuliding = [
    { id: "Duplex", label: "Duplex" },
    { id: "Apartment", label: "Apartment" },
    { id: "Complex", label: "Complex" },
    { id: "Individual", label: "Individual" },
  ];

  const [address, setAddress] = useState("");

  const joinAddress = () => {
    // Combine the address components into a single string with proper formatting.
    const joinedAddress = `${allNewContractDetails.premesisDoorNumber}, ${allNewContractDetails.premesisFloorNumber}, ${allNewContractDetails.premesisLandMark}, ${allNewContractDetails.premesisStreet},${allNewContractDetails.premesisWardNo},
    ${allNewContractDetails.premesisCity},${allNewContractDetails.premesisPinCode},${allNewContractDetails.premesisTaluka},${allNewContractDetails.premesisDistrict},${allNewContractDetails.premesisState}`;
    setAddress(joinedAddress);
  };

  return (
    <>
      <Box sx={{ height: "calc(100% - 55px)", overflowY: "scroll" }}>
        <Box>
          <Typography className="fs-20 fw-500 pt-4 px-3">
            Branch/Office Hierarchy Details
          </Typography>
          <Grid container spacing={2} className="px-2 py-2 mt-1">
            <Grid item className="d-flex m-2" lg={12}>
              <DropDownComponent
                label="Premesis Type"
                sx={{ width: 300 }}
                options={BranchType}
                name="lesseeBranchType"
                value={allNewContractDetails?.lesseeBranchType}
                // onSelect={handleBranchType}
                onChange={(value) =>
                  handleBranchType("lesseeBranchType", value)
                }
              />

              <DropDownComponent
                label="Entity Details "
                sx={{ width: 300 }}
                options={EntityDetails}
                name="lesseeEntityDetails"
                value={allNewContractDetails?.lesseeEntityDetails}
                // onSelect={handleEntityDetails}
                onChange={(val) =>
                  handleEntityDetails("lesseeEntityDetails", val)
                }
              />
            </Grid>
          </Grid>

          {allNewContractDetails?.lesseeBranchType ? (
            <Grid container spacing={2} className="px-2 py-2 mt-1">
              <Grid item className="d-flex m-2" lg={12}>
                <InputBoxComponent
                  label="Branch ID"
                  placeholder="Enter Branch ID."
                  sx={{ width: 300 }}
                  name="branchID"
                  value={allNewContractDetails?.branchID}
                  onChange={(e) => updateChange(e)}
                  errorText={allNewContractDetailsErr?.branchID}
                />
              </Grid>
              <Grid item className="d-flex m-2" lg={12}>
                <InputBoxComponent
                  label="Branch Name"
                  placeholder="Enter Branch Name."
                  sx={{ width: 300 }}
                  name="lesseeBranchName"
                  value={allNewContractDetails?.lesseeBranchName}
                  onChange={(e) => updateChange(e)}
                  errorText={allNewContractDetailsErr?.lesseeBranchName}
                />
                <InputBoxComponent
                  label="Area Name"
                  placeholder="Enter Area Name ."
                  sx={{ width: 300 }}
                  name="lesseeAreaName"
                  value={allNewContractDetails?.lesseeAreaName}
                  onChange={(e) => updateChange(e)}
                  errorText={allNewContractDetailsErr?.lesseeAreaName}
                />
                <InputBoxComponent
                  label="Division/Region"
                  placeholder="Enter Div/Reg No."
                  sx={{ width: 300 }}
                  name="lesseeDivision"
                  value={allNewContractDetails?.lesseeDivision}
                  onChange={(e) => updateChange(e)}
                  errorText={allNewContractDetailsErr?.lesseeDivision}
                />
              </Grid>
              <Grid item className="d-flex m-2" lg={12}>
                <InputBoxComponent
                  label="Zone"
                  placeholder="Enter Zone ."
                  sx={{ width: 300 }}
                  name="lesseeZone"
                  value={allNewContractDetails?.lesseeZone}
                  onChange={(e) => updateChange(e)}
                  errorText={allNewContractDetailsErr?.lesseeZone}
                />
                <InputBoxComponent
                  label="State"
                  placeholder="Enter State ."
                  sx={{ width: 300 }}
                  name="lesseeState"
                  value={allNewContractDetails?.lesseeState}
                  onChange={(e) => updateChange(e)}
                  errorText={allNewContractDetailsErr?.lesseeState}
                />
              </Grid>
            </Grid>
          ) : null}

          {/* <Box> */}
          {/* <Typography className="fs-20 fw-500 pt-4 px-3">
              Lessee Branch Details
            </Typography>
            <Grid container spacing={2} className="px-2 py-2 mt-1">
              <Grid item className="d-flex m-2" lg={12}>
                <DropDownComponent
                  label="Branch Type"
                  sx={{ width: 300 }}
                  options={BranchType}
                  name="lesseeBranchType"
                  value={allNewContractDetails?.lesseeBranchType}
                  // onSelect={handleBranchType}
                  onChange={(value) =>
                    handleBranchType("lesseeBranchType", value)
                  }
                />

                <DropDownComponent
                  label="Approver-Renewals "
                  sx={{ width: 300 }}
                  options={ApproverRenew}
                  name="lesseeApproverrenewals"
                  value={allNewContractDetails?.lesseeApproverrenewals}
                  // onSelect={handleApproverRenew}
                  onChange={(value) =>
                    handleApproverRenew("lesseeApproverrenewals", value)
                  }
                /> 
              </Grid> */}
          {/* <Grid item className="d-flex m-2" lg={12}>
                <DropDownComponent
                  label="Approver-Relocations/New "
                  sx={{ width: 300 }}
                  options={ApproverRelocate}
                  name="lesseeApproverRelocation"
                  value={allNewContractDetails?.lesseeApproverRelocation}
                  // onSelect={handleApproverRelocate}
                  onChange={(value) =>
                    handleApproverRelocate("lesseeApproverRelocation", value)
                  }
                />

                 <DropDownComponent
                  label="Entity Details "
                  sx={{ width: 300 }}
                  options={EntityDetails}
                  name="lesseeEntityDetails"
                  value={allNewContractDetails?.lesseeEntityDetails}
                  // onSelect={handleEntityDetails}
                  onChange={(val) =>
                    handleEntityDetails("lesseeEntityDetails", val)
                  }
                />
              </Grid> */}
          {/* </Grid> */}
          {/* </Box> */}
        </Box>

        <Box
          className="d-flex justify-content-center w-100"
          sx={{ height: "calc(100% - 55px)" }}
        >
          <Box>
            <Typography className="fs-20 fw-500 pt-4 px-3">
              Premesis Details
            </Typography>
            <Grid container spacing={2} className="px-2 py-2 mt-1">
              <Grid item className="d-flex m-2" lg={12}>
                <DropDownComponent
                  label="Location"
                  sx={{ width: 300 }}
                  options={location}
                  name="premesisLocation"
                  // onSelect={handleLocationChange}
                  value={allNewContractDetails?.premesisLocation}
                  onChange={(val) =>
                    handleLocationChange("premesisLocation", val)
                  }
                />
                <DropDownComponent
                  label="Building Type"
                  sx={{ width: 300 }}
                  options={typeOfBuliding}
                  name="branchName"
                  value={allNewContractDetails?.premesisBuildingType}
                  // onSelect={handleBulidingType}
                  onChange={(val) =>
                    handleBulidingType("premesisBuildingType", val)
                  }
                />
              </Grid>
            </Grid>

            {/* <Box>
              <Typography className="fs-20 fw-500 pt-4 px-3">
                Office Hierarchy
              </Typography>
              <Grid container spacing={2} className="px-2 py-2 mt-1">
                <Grid item className="d-flex m-2" lg={12}>
                  <InputBoxComponent
                    label="Branch ID"
                    placeholder="Enter Branch ID"
                    sx={{ width: 300 }}
                    name="branchID"
                    value={allNewContractDetails?.branchID}
                    onChange={(e) => updateChange(e)}
                    errorText={allNewContractDetailsErr?.branchID}
                  />
                  <InputBoxComponent
                    label="Branch Name"
                    placeholder="Enter Branch Name"
                    sx={{ width: 300 }}
                    name="premesisBranchName"
                    value={allNewContractDetails?.premesisBranchName}
                    onChange={(e) => updateChange(e)}
                    errorText={allNewContractDetailsErr?.premesisBranchName}
                  />
                  <InputBoxComponent
                    label="Area Name"
                    placeholder="Enter Area Name ."
                    sx={{ width: 300 }}
                    name="premesisAreaName"
                    value={allNewContractDetails?.premesisAreaName}
                    onChange={(e) => updateChange(e)}
                    errorText={allNewContractDetailsErr?.premesisAreaName}
                  />
                </Grid>
                <Grid item className="d-flex m-2" lg={12}>
                  <InputBoxComponent
                    label="Division/Region"
                    placeholder="Division/Region"
                    sx={{ width: 300 }}
                    name="premesisDivision"
                    value={allNewContractDetails?.premesisDivision}
                    onChange={(e) => updateChange(e)}
                    errorText={allNewContractDetailsErr?.premesisDivision}
                  />
                  <InputBoxComponent
                    label="Zone"
                    placeholder="Enter Zone ."
                    sx={{ width: 300 }}
                    name="premesisZone"
                    value={allNewContractDetails?.premesisZone}
                    onChange={(e) => updateChange(e)}
                    errorText={allNewContractDetailsErr?.premesisZone}
                  />
                  <InputBoxComponent
                    label="State"
                    placeholder="Enter State ."
                    sx={{ width: 300 }}
                    name="premesisState"
                    value={allNewContractDetails?.premesisState}
                    onChange={(e) => updateChange(e)}
                    errorText={allNewContractDetailsErr?.premesisState}
                  />
                </Grid>
              </Grid>

              
            </Box> */}

            <Grid item className="d-flex m-3" lg={12}></Grid>
            <Box>
              <Typography className="fs-20 fw-500 pt-4 px-3">
                Premises Address Details
              </Typography>
              <Grid container spacing={2} className="px-2 py-2 mt-1">
                <Grid item className="d-flex m-2" md={12}>
                  <InputBoxComponent
                    label="Door No."
                    placeholder="Enter Door No."
                    sx={{ width: 300 }}
                    name="premesisDoorNumber"
                    value={allNewContractDetails?.premesisDoorNumber}
                    onChange={(e) => updateChange(e)}
                    errorText={allNewContractDetailsErr?.premesisDoorNumber}
                  />
                  <InputBoxComponent
                    label="Floor No."
                    placeholder="Enter Floor No."
                    sx={{ width: 300 }}
                    name="premesisFloorNumber"
                    value={allNewContractDetails?.premesisFloorNumber}
                    onChange={(e) => updateChange(e)}
                    errorText={allNewContractDetailsErr?.premesisFloorNumber}
                  />
                  <InputBoxComponent
                    label="Land Mark"
                    placeholder="Enter Land Mark"
                    sx={{ width: 300 }}
                    name="premesisLandMark"
                    value={allNewContractDetails?.premesisLandMark}
                    onChange={(e) => updateChange(e)}
                    errorText={allNewContractDetailsErr?.premesisLandMark}
                  />
                </Grid>
                <Grid item className="d-flex m-2" md={12}>
                  <InputBoxComponent
                    label="Road/Street"
                    placeholder="Enter Road"
                    sx={{ width: 300 }}
                    name="premesisStreet"
                    value={allNewContractDetails?.premesisStreet}
                    onChange={(e) => updateChange(e)}
                    errorText={allNewContractDetailsErr?.premesisStreet}
                  />
                  <InputBoxComponent
                    label="Ward Name/No Area Name/Layout Name/Extension"
                    placeholder="Enter Ward No."
                    sx={{ width: 300 }}
                    name="premesisWardNo"
                    value={allNewContractDetails?.premesisWardNo}
                    onChange={(e) => updateChange(e)}
                    errorText={allNewContractDetailsErr?.premesisWardNo}
                  />
                  <InputBoxComponent
                    label="City"
                    sx={{ width: 300 }}
                    placeholder="Enter City"
                    name="premesisCity"
                    value={allNewContractDetails?.premesisCity}
                    onChange={(e) => updateChange(e)}
                    errorText={allNewContractDetailsErr?.premesisCity}
                  />
                </Grid>
                <Grid item className="d-flex m-2" md={12}>
                  <InputBoxComponent
                    label="Pincode"
                    placeholder="Enter Pincode"
                    sx={{ width: 300 }}
                    name="premesisPinCode"
                    value={allNewContractDetails?.premesisPinCode}
                    onChange={(e) => updateChange(e)}
                    errorText={allNewContractDetailsErr?.premesisPinCode}
                  />
                  <InputBoxComponent
                    label="Taluk"
                    placeholder="Enter Taluk"
                    sx={{ width: 300 }}
                    name="premesisTaluka"
                    value={allNewContractDetails?.premesisTaluka}
                    onChange={(e) => updateChange(e)}
                    errorText={allNewContractDetailsErr?.premesisTaluka}
                  />

                  <InputBoxComponent
                    label="District "
                    sx={{ width: 300 }}
                    placeholder="Enter District"
                    name="premesisDistrict"
                    value={allNewContractDetails?.premesisDistrict}
                    onChange={(e) => updateChange(e)}
                    errorText={allNewContractDetailsErr?.premesisDistrict}
                  />
                </Grid>
                <Grid item className="d-flex m-2" md={12}>
                  <InputBoxComponent
                    label="State "
                    sx={{ width: 300 }}
                    placeholder="Enter State"
                    name="premesisState"
                    value={allNewContractDetails?.premesisState}
                    onChange={(e) => updateChange(e)}
                    errorText={allNewContractDetailsErr?.premesisState}
                  />
                </Grid>

                <Grid item className="d-flex m-2" md={12}>
                  <InputBoxComponent
                    label="Plot Area"
                    placeholder="Enter Plot Area ."
                    sx={{ width: 300 }}
                    name="plotNumber"
                    value={allNewContractDetails?.plotNumber}
                    onChange={(e) => updateChange(e)}
                    errorText={allNewContractDetailsErr?.plotNumber}
                  />
                  <InputBoxComponent
                    label="Buit-Up Area"
                    placeholder="Enter Bulit-Up Area ."
                    sx={{ width: 300 }}
                    name="builtupArea"
                    value={allNewContractDetails?.builtupArea}
                    onChange={(e) => updateChange(e)}
                    errorText={allNewContractDetailsErr?.builtupArea}
                  />
                </Grid>

                <Grid
                  item
                  className="d-flex flex-column align-items-start justify-content-start m-3"
                  md={12}
                >
                  <Button onClick={joinAddress}>Join Address</Button>
                  {address && (
                    <InputBoxComponent
                      label="Address"
                      placeholder="Enter Address"
                      multiline
                      sx={{ width: 300 }}
                      size="large"
                      value={address}
                      readOnly
                    />
                  )}
                </Grid>

                <Box
                  className="d-flex justify-content-center w-100"
                  sx={{ overflow: "hidden" }}
                >
                  <Box>
                    <Typography className="fs-20 fw-500 pt-4 px-4">
                      GPS Details
                    </Typography>
                    <Grid container spacing={2} className="px-3 py-0 mt-0">
                      <Grid item className="d-flex m-2" md={12}>
                        <InputBoxComponent
                          label="Lattitude"
                          placeholder="Enter Lattitude"
                          sx={{ width: 300 }}
                          name="lattitude"
                          value={allNewContractDetails?.lattitude}
                          onChange={(e) => updateChange(e)}
                          errorText={allNewContractDetailsErr?.lattitude}
                        />
                        <InputBoxComponent
                          label="Longitude"
                          placeholder="Enter Longitude"
                          sx={{ width: 300 }}
                          name="longitude"
                          value={allNewContractDetails?.longitude}
                          onChange={(e) => updateChange(e)}
                          errorText={allNewContractDetailsErr?.longitude}
                        />

                        <InputBoxComponent
                          label="GPS Co-ordinates"
                          placeholder="Enter GPS Co-ordinates"
                          sx={{ width: 300 }}
                          name="gpsCoordinates"
                          value={allNewContractDetails?.gpsCoordinates}
                          onChange={(e) => updateChange(e)}
                          errorText={allNewContractDetailsErr?.gpsCoordinates}
                        />
                      </Grid>
                    </Grid>
                  </Box>
                </Box>
              </Grid>
            </Box>
          </Box>
        </Box>
      </Box>

      <Box className="d-flex justify-content-end w-100">
        <Button
          disabled={activeStep && activeStep === 0}
          onClick={handleBack}
          variant="contained"
          sx={{ m: 1 }}
        >
          Back
        </Button>
        <Button
          disabled={activeStep && activeStep === 0}
          onClick={handleNext}
          variant="contained"
          sx={{ m: 1, background: "#238520" }}
        >
          Next
        </Button>
      </Box>
    </>
  );
};

export default LesseeInformation;
