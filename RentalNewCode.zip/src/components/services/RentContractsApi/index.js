import serviceUtil from "../ServiceUtil";

const getBranchID = (params) => {
  return serviceUtil
    .get(`getbranchids`)
    .then((res) => {
      console.log(res, "res");
      const data = res.data;
      return { data };
    })
    .catch((err) => {
      const errRes = err;
      return { errRes };
    });
};

// const getRentContractDetailsOnBranchID = (params) => {
//   return serviceUtil
//     .get(`getcontracts?branchID=${params}`)
//     .then((res) => {
//       console.log(params, "params");
//       console.log(res, "res");
//       const data = res.data;
//       return { data };
//     })
//     .catch((err) => {
//       const errRes = err;
//       return { errRes };
//     });
// };

const getAllRentContractDetails = () => {
  return serviceUtil
    .get(`getallcontracts`)
    .then((res) => {
      // console.log(res, "res");
      const data = res.data;
      return { data };
    })
    .catch((err) => {
      const errRes = err;
      return { errRes };
    });
};

export { getAllRentContractDetails, getBranchID };
