const columns = [
  { id: "1", label: "Sl.No.", minWidth: 10, align: "center" },
  { id: "2", label: "Direction", minWidth: 10, align: "center" },
  { id: "3", label: "Description", minWidth: 70, align: "center" },
];

export { columns };
