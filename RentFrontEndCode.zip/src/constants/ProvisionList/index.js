const ProvisionsColumns = [
  { id: "provisionID", label: "Provision ID", align: "center" },
  { id: "contractID", label: "ID", align: "center" },
  { id: "branchID", label: "Branch ID", align: "center" },
  { id: "provisiontype", label: "Provision Type", align: "center" },
  { id: "year", label: "Year", align: "center" },
  { id: "month", label: "Month", align: "center" },
  { id: "provisionAmount", label: "Provisions", align: "center" },
  { id: "remark", label: "Remarks", align: "center" },
];
export { ProvisionsColumns };
