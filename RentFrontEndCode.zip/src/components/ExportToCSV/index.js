import React from "react";
import { CSVLink } from "react-csv";
import Button from "react-bootstrap/Button";

export const ExportToCSV = ({ excelData, fileName }) => {
  return (
    <Button variant="warning">
      <CSVLink data={excelData} filename={fileName}>
        Export
      </CSVLink>
    </Button>
  );
};
