export const dummyUsers = [
  { username: "Ramya", password: "Ramya1" },
  { username: "Ankeet", password: "Ankeet1" },
];
