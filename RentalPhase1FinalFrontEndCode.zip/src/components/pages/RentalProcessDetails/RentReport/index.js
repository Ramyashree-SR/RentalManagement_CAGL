import React from 'react'

const RentReport = () => {
  return (
    <div>RentReport</div>
  )
}

export default RentReport
