export const dummyUsers = [
  { username: "Janardhan1", password: "Janardhan1" },
  { username: "Janardhan2", password: "Janardhan2" },
];
